<html xmlns:t="http://twistedmatrix.com/ns/twisted.web.template/0.1">
  <head>
    <title>Tor2web Error: Invalid Hostname</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta http-equiv="content-language" content="en" />
    <meta name="robots" content="noindex" />
    <script type="text/javascript" src="/antanistaticmap/tor2web.js"></script>
    <link rel="stylesheet" type="text/css" href="/antanistaticmap/tor2web.css" />
  </head>
  <body>
    <div id="tor2web">
      <div id="header">
        <h1><a href="https://www.tor2web.org"><img src="/antanistaticmap/tor2web.png" alt="tor2web logo" /></a></h1>
      </div>
      <div id="tor2web-content">
        <h2 id="tor2web-title">Tor2web Error: Invalid Hostname</h2>
        <p>Sorry, we couldn't serve the page you requested.</p>
        <ol>
          <li><p><strong>The entered URL is invalid.</strong> This most likely happens if you get this page immediately after trying to visit a URL. This service only works with valid <code>.onion</code> URLs. Please check your URL and try again.</p></li>
        </ol>
      </div>
    </div>
  </body>
</html>
